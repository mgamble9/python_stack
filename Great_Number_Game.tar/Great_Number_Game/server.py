from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key = "ThisIsSecret"

@app.route('/')
def index():
    if 'answer' not in session:
        session['answer'] = random.randrange(1,101)
    print session['answer']
    result_box_str = '<div id="no_div"></div>'
    return render_template('index.html', result_box_str=result_box_str)

@app.route('/submit_guess', methods=['POST'])
def playgame():
    print request.form
    guess = int(request.form['guess'])
    if 'answer' not in session:
        return redirect('/')
    if guess == session['answer']:
        session.pop('answer')
        result_box_str ='<div id="right_answer_div"><h2>'+str(guess)+' was the number!</h2><form action="/new_game" method = "post"><input type="submit" value="New Game?"></form></div>'
        return render_template('index.html', result_box_str=result_box_str)
    elif guess < session['answer']:
        result_box_str = '<div id="wrong_answer_div"><h1>Too Low!</h1></div>'
        return render_template('index.html', result_box_str=result_box_str)
    elif guess > session['answer']:
        result_box_str = '<div id="wrong_answer_div"><h1>Too High!</h1></div>'
        return render_template('index.html', result_box_str=result_box_str)

@app.route('/new_game', methods=['POST'])
def newgame():
    return redirect('/')


app.run(debug=True)
