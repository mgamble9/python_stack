from flask import Flask, render_template, request, redirect, session
import random
import math
app = Flask(__name__)
app.secret_key = "ThisIsSecret"

@app.route('/')
def index():
    if 'answer' not in session:
        session['answer'] = random.randrange(1,101)
    print 'DON\'T CHEAT AND LOOK HERE AT THE ANSWER!!!  ' + str(session['answer'])
    result_box_str = '<div id="no_div"></div>'
    return render_template('index.html', result_box_str=result_box_str)

@app.route('/submit_guess', methods=['POST'])
def playgame():
    print request.form
    if request.form['guess'] is None:
            return redirect('/')

    guess = int(request.form['guess'])

    #
    # I tried to use various redirects here to stop the
    # thing from breaking but no luck.
    #
    if guess is None:
        return redirect('/')

    if math.isnan(guess) or guess is None:
        return redirect('/')

    if guess is None:
        return redirect('/')

    #
    #below is my clugy way for stopping the thing from breaking
    #if the user tries entering another number when the game has
    #ended and the request is made for a new game.
    #
    if 'answer' not in session:
        return redirect('/')
    if guess == session['answer']:
        session.pop('answer')
        result_box_str ='<div id="right_answer_div"><h2>'+str(guess)+' was the number!</h2><form action="/new_game" method = "post"><input type="submit" value="New Game?"></form></div>'
        return render_template('index.html', result_box_str=result_box_str)
    elif guess < session['answer']:
        result_box_str = '<div id="wrong_answer_div"><h1>'+str(guess)+'? Too Low!</h1></div>'
        return render_template('index.html', result_box_str=result_box_str)
    elif guess > session['answer']:
        result_box_str = '<div id="wrong_answer_div"><h1>'+str(guess)+'? Too High!</h1></div>'
        return render_template('index.html', result_box_str=result_box_str)

@app.route('/new_game', methods=['POST'])
def newgame():
    return redirect('/')

app.run(debug=True)
