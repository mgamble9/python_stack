from flask import Flask, render_template, request, redirect
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ninja')
def ninja():
    return render_template('ninja.html')

@app.route('/ninja/<ninja_color>')
def ninja_color(ninja_color):
    if ninja_color == "red":
        ninja_img = "raphael.jpg"
    elif ninja_color == "blue":
        ninja_img = "leonardo.jpg"
    elif ninja_color == "purple":
        ninja_img = "donatello.jpg"
    elif ninja_color == "orange":
        ninja_img = "michelangelo.jpg"
    else:
        ninja_img = "notapril.jpg"
    print ninja_img
    return render_template('ninja_color.html', ninja_img=ninja_img)

app.run(debug=True) # run our server
