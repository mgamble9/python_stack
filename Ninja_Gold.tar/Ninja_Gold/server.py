from flask import Flask, render_template, request, redirect, session
import random
import datetime
app = Flask(__name__)
app.secret_key = "ThisIsSecret"

def get_time_now():
    return datetime.datetime.now().strftime('(%Y/%m/%d %-I:%M %p)')

@app.route('/')
def index():
    if 'activities' not in session:
        session['gold'] = 0
        session['activities'] = []
    total_gold = session['gold']
    # print "Gold is",total_gold
    # print "The activities are",session['activities']
    return render_template('index.html', total_gold=total_gold)

@app.route('/process_money', methods=['POST'])
def gameplay():
    print request.form
    if request.form['building'] == 'farm':
        gold_earned = random.randrange(10,20)
        session['gold'] += gold_earned
        time_str = get_time_now()
        stringout = "Earned " + str(gold_earned) + " from the farm! " + time_str
        html_out = '<p style="color:green;">' + stringout + '</p>'
        session['activities'].append(html_out)
    elif request.form['building'] == 'cave':
        gold_earned = random.randrange(5,10)
        session['gold'] += gold_earned
        time_str = get_time_now()
        stringout = "Earned " + str(gold_earned) + " from the cave! " + time_str
        html_out = '<p style="color:green;">' + stringout + '</p>'
        session['activities'].append(html_out)
    elif request.form['building'] == 'house':
        gold_earned = random.randrange(2,5)
        session['gold'] += gold_earned
        time_str = get_time_now()
        stringout = "Earned " + str(gold_earned) + " from the house! " + time_str
        html_out = '<p style="color:green;">' + stringout + '</p>'
        session['activities'].append(html_out)
    elif request.form['building'] == 'casino':
        gold_earned = random.randrange(-50,50)
        session['gold'] += gold_earned
        time_str = get_time_now()
        if gold_earned < 0:
            stringout = "Lost " + str(gold_earned) + " at the casino! " + time_str
            html_out = '<p style="color:red;">' + stringout + '</p>'
        else:
            stringout = "Earned " + str(gold_earned) + " at the casino! " + time_str
            html_out = '<p style="color:green;">' + stringout + '</p>'
        session['activities'].append(html_out)

    return redirect('/')

@app.route('/reset_game')
def reset_game():
    session['gold'] = 0
    session['activities'] = []
    return redirect('/')

app.run(debug=True)
