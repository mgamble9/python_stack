from flask import Flask, render_template, request, redirect, flash, url_for
import re

app = Flask(__name__)
app.secret_key = 'some_secret'

# def check_for_null_input(arg):
#     if len(arg) < 1:
#         # print "This is arg " + arg
#         message = 'You did not enter a ' + arg
#         return flash(message , 'error')

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/registration', methods=['POST'])
def registration():
    # print request.form
    first_name = str(request.form['first_name'])
    # print "First name",first_name
    # print type(first_name)
    failed_input = False

    if len(first_name) <1:
        message = 'You did not enter a first name'
        flash(message, 'error')
        failed_input = True

    # check_for_null_input(first_name)
    last_name = str(request.form['last_name'])
    if len(last_name) <1:
        message = 'You did not enter a last name'
        flash(message, 'error')
        failed_input = True

    # check_for_null_input(last_name)
    password = request.form['password']
    if len(password) <1:
        message = 'You did not enter a password'
        flash(message, 'error')
        failed_input = True

    # check_for_null_input(password_confirmation)
    confirm_password = request.form['password_confirmation']
    if len(confirm_password) <1:
        message = 'You did not enter a password confirmation'
        flash(message, 'error')
        failed_input = True

    # check_for_null_input(email)
    email = request.form['email']
    if len(email) <1:
        message = 'You did not enter your email address.'
        flash(message, 'error')
        failed_input = True

    # check names for correctness
    if not str.isalpha(first_name):
        message = 'You did not enter a proper first name.'
        flash(message, 'error')
        failed_input = True

    if not str.isalpha(last_name):
        message = 'You did not enter a proper last name.'
        flash(message, 'error')
        failed_input = True

    # check password for less than 8 char lenght

    if len(password) >8:
        message = 'The password should be 8 characters or less'
        flash(message, 'error')
        failed_input = True

    # check for valid email

    if not EMAIL_REGEX.match(email):
        message = 'Invalid email address entered.'
        flash(message, 'error')
        failed_input = True

    # check for password confirmation match

    if password != confirm_password:
        message = 'Passwords do not match.'
        flash(message, 'error')
        failed_input = True

    if not failed_input:
        message = 'You successfully entered your registration'
        flash(message, 'success')


    return render_template('index.html')

    # return redirect('/')

app.run(debug=True)
