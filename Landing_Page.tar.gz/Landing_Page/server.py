from flask import Flask, render_template, request, redirect
app = Flask(__name__)
# our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html", phrase="hello")

@app.route('/ninjas')
def ninjas():
  return render_template("ninjas.html")

@app.route('/dojos/new', methods=['POST'])
def dojos():
   print request.form
   print "Got Post Info"
   # we'll talk about the following two lines after we learn a little more
   # about forms
   name = request.form['name']
   email = request.form['email']
   return render_template('dojos.html')
   # redirects back to the '/' route
   # return redirect('/')
# def create_user():
#    print request.form
#    print "Got Post Info"
#    # we'll talk about the following two lines after we learn a little more
#    # about forms
#    name = request.form['name']
#    email = request.form['email']
#
#    # redirects back to the '/' route
#    return redirect('/')
app.run(debug=True) # run our server
