from flask import Flask, render_template, request, redirect
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/survey', methods=['POST'])
def survey():
    print request.form
    print "Got Post Info"
    name = request.form['full_name']
    if len(name) < 1:
        return redirect('/')
    city = request.form['city']
    language = request.form['language']
    comment = request.form['comment']
    if len(comment) < 1 or len(comment) > 120:
        return redirect('/')
    return render_template('survey.html',full_name=name,city=city,language=language,comment=comment)

@app.route('/index', methods=['POST'])
def return_to_index():
    print request.form
    return render_template('index.html')

app.run(debug=True) # run our server
