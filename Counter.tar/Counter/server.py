from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'
def sumSessionCounter():
  try:
    session['count_visits'] += 1
  except KeyError:
    session['count_visits'] = 1
@app.route('/')
def index():
    sumSessionCounter()
    return render_template('index.html')

@app.route('/button_plus2', methods=['POST'])
def return_to_index():
    print request.form
    session['count_visits'] += 2
    return render_template('index.html')
    # return redirect('/')

@app.route('/button_reset', methods=['POST'])
def reset_button():
    print request.form
    session['count_visits'] = 0
    return redirect('/')

    # session['name'] = request.form['name']
    # session['email'] = request.form['email']
# return redirect('/show')
  # return render_template('user.html', name=session['name'], email=session['email'])
  #
#or we can access the session data directly form the templates in HTML
    # <h3>{{session['name']}}</h3>
    # <h3>{{session['email']}}</h3>
app.run(debug=True) # run our server
